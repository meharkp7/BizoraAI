import { writeFileSync, mkdirSync } from 'node:fs';
const S = (type: string, extra: object = {}) => ({ type, ...extra });
const str = S('string'), num = S('number'), bool = S('boolean');
const arr = (items: object) => S('array', { items });
const obj = (properties: Record<string, object>, required: string[] = [], extra: object = {}) => S('object', { properties, required, additionalProperties: false, ...extra });
const evidence = obj({ figure_id: str, page: S('integer'), bbox: arr(num), quote: str });
const conf = S('number', { minimum: 0, maximum: 1 });
const side = S('string', { enum: ['left', 'right', 'up', 'down'] });

const circuit = obj({
  version: S('integer', { enum: [1] }), title: str, source: obj({ figure_id: str, page: S('integer') }),
  components: arr(obj({
    id: str, type: str, label: str, value: str, pins: S('object', { additionalProperties: str }),
    placement: obj({ x: num, y: num, rot: S('integer', { enum: [0, 90, 180, 270] }), mirror: bool, flip: bool }, ['x', 'y']),
    pin_sides: S('object', { additionalProperties: side }), confidence: conf, evidence,
  }, ['id', 'type', 'pins'])),
  nets: arr(obj({ id: str, label: str, role: S('string', { enum: ['supply', 'ground', 'signal', 'clock', 'input', 'output'] }), global: bool }, ['id'])),
  ports: arr(obj({ id: str, net: str, label: str, dir: S('string', { enum: ['in', 'out', 'inout'] }), side, placement: obj({ x: num, y: num }, ['x', 'y']) }, ['id', 'net'])),
  subcircuits: arr(obj({ id: str, label: str, component_ids: arr(str) }, ['id', 'component_ids'])),
  layout: obj({ unit: num }),
}, ['version', 'components', 'nets']);

const methodology = obj({
  version: S('integer', { enum: [1] }), title: str, source: obj({ figure_id: str, page: S('integer') }),
  groups: arr(obj({ id: str, label: str, parent: str }, ['id', 'label'])),
  nodes: arr(obj({
    id: str, label: str, kind: S('string', { enum: ['input', 'process', 'decision', 'store', 'model', 'evaluation', 'dataset', 'output'] }), group: str, detail: str,
    params: S('object', { additionalProperties: S('string') }), confidence: conf, evidence,
  }, ['id', 'label'])),
  edges: arr(obj({ from: str, to: str, label: str, kind: S('string', { enum: ['data', 'control', 'feedback'] }) }, ['from', 'to'])),
}, ['version', 'nodes', 'edges']);

const block: Record<string, unknown> = {
  type: 'object', additionalProperties: false, required: ['id', 'label', 'kind'],
  properties: {
    id: str, label: str, kind: S('string', { enum: ['chip', 'array', 'cell', 'periphery', 'module', 'board', 'layer', 'part', 'region'] }),
    count: { oneOf: [S('integer', { minimum: 1 }), obj({ rows: S('integer', { minimum: 1 }), cols: S('integer', { minimum: 1 }) }, ['rows', 'cols'])] },
    dims: obj({ w: num, h: num, d: num, unit: str }), pos: { oneOf: [S('string', { enum: ['left', 'right', 'top', 'bottom', 'center'] }), obj({ x: num, y: num }, ['x', 'y'])] },
    part: str, tensor_shape: arr(S('integer')), confidence: conf, evidence, children: arr({ $ref: '#/definitions/Block' }),
  },
};
const structure = { type: 'object', additionalProperties: false, required: ['version', 'root'], definitions: { Block: block },
  properties: { version: S('integer', { enum: [1] }), title: str, source: obj({ figure_id: str, page: S('integer') }), root: { $ref: '#/definitions/Block' } } };

mkdirSync('schemas', { recursive: true });
for (const [n, s] of Object.entries({ circuit, methodology, structure }))
  writeFileSync(`schemas/${n}.schema.json`, JSON.stringify({ $schema: 'http://json-schema.org/draft-07/schema#', title: `${n}-ir`, ...s }, null, 2));
console.log('schemas written');
