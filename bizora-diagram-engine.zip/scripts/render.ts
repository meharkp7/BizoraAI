import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import sharp from 'sharp';
import { renderSchematic } from '../src/schematic.js';
import { renderMethodology } from '../src/methodology.js';
import { renderStructureIso } from '../src/structure.js';
import { dark, light } from '../src/theme.js';

const only = process.argv[2];
mkdirSync('out', { recursive: true });
async function png(name: string, svg: string) {
  writeFileSync(`out/${name}.svg`, svg);
  await sharp(Buffer.from(svg), { density: 110 }).png().toFile(`out/${name}.png`);
}
const load = (f: string) => JSON.parse(readFileSync(`fixtures/${f}.json`, 'utf8'));
for (const [name, theme] of [['dark', dark], ['light', light]] as const) {
  for (const f of ['circuit_6t', 'circuit_amp']) if (!only || f.includes(only)) await png(`${f}.${name}`, renderSchematic(load(f), { theme }).svg);
  if (!only || 'methodology'.includes(only)) await png(`methodology_puf.${name}`, renderMethodology(load('methodology_puf'), { theme }).svg);
  for (const f of ['structure_array', 'structure_layers']) if (!only || 'structure'.includes(only)) await png(`${f}.${name}`, renderStructureIso(load(f), { theme }).svg);
}
console.log('rendered');
