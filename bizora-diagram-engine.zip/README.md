# Bizora diagram engine

Renderer-only. It draws what an **intermediate representation (IR)** says and nothing else. The IRs are produced from the paper
(figures + text) by the extraction pipeline; the engine never invents content, has no built-in diagrams and no domain logic.

| IR | Renders to | Function |
|---|---|---|
| `CircuitIR` | schematic (SVG) with standard symbols, routed wires, junctions, rail symbols | `renderSchematic` / `renderCircuitSafe` |
| `MethodologyIR` | grouped flow diagram (SVG) with labelled arrows, kind-specific shapes, evidence tags | `renderMethodology` / `renderMethodologySafe` |
| `StructureIR` | renderer-agnostic 3D `Scene` (boxes) + isometric SVG preview; Three.js adapter | `buildStructureScene` / `buildStructureSafe`, `renderStructureIso`, `sceneToThree` |

## Contract (important)
1. **Use the `*Safe` functions in the app.** They validate first. If the IR is invalid or too thin to be a real diagram they return
   `{ ok:false, reason }`. The app must then show the **paper's own figure** (with click overlays), never a made-up picture.
2. Everything in `fixtures/` is **test data**. Fixture IRs set `source.figure_id = "fixture"`, which stamps
   "TEST FIXTURE · NOT FROM A PAPER" on the output so a canned diagram can never pass as paper output. Do not ship fixtures as product data.
3. Placement: if every component has `placement` (taken from where it appears in the figure) the engine keeps the paper's layout
   (`layout.unit` or auto-scale). Without placement it falls back to a basic auto-layout, which is much weaker. Extraction should
   therefore always return placement from the figure.
4. Labels: elements with `confidence < 0.6` are drawn dashed; evidence pages are shown as small tags. Keep from-paper / assumed /
   illustrative / measured labels in the UI around these views.
5. Structure dims: `w` = x extent, `d` = y extent, `h` = height, relative units (normalized to the cell width).

## Interaction hooks
- Schematic: each component group has `data-id` (component id). Methodology: each node group has `data-node-id`.
- 3D: `sceneToThree(scene)` sets `mesh.userData = { id, label, kind, part }` for picking -> inspector/evidence.
- Scene axes: x east, y south, z up (the adapter maps to Three.js y-up).

## Develop
```
npm install
npm test            # engine tests
npx tsx scripts/render.ts   # renders fixtures to out/*.png|svg
npx tsx scripts/gen-schemas.ts   # regenerates schemas/*.schema.json (use for structured output)
```
Integration in the React app: copy `src/` to `frontend/src/diagram-engine/`, add dependency `@dagrejs/dagre`, render the returned SVG string
inside a container (sanitized) and attach click handlers using the `data-*` ids.

## Known limits (be honest in the UI)
- Wire routing is heuristic. It gives readable results on small/medium circuits when placement comes from the figure; very dense
  circuits may need manual touch-up (edit UI).
- Symbol set: transistors (nmos/pmos), R, C, L, diode, sources, ground, inverter, buffer, amp, comparator, generic block.
- Structure view draws boxes; real component 3D models (GLB) come from the asset registry and plug into the Scene boxes by `part`.
- Auto-layout (no placement) is basic.
