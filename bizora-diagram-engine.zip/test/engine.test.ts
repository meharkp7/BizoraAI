import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validateCircuit, validateMethodology, validateStructure, renderCircuitSafe, renderMethodologySafe, buildStructureSafe, renderSchematic, renderMethodology, buildStructureScene } from '../src/index.js';

const load = (f: string) => JSON.parse(readFileSync(new URL(`../fixtures/${f}.json`, import.meta.url), 'utf8'));

test('6T fixture validates and routes every net', () => {
  const ir = load('circuit_6t'); const v = validateCircuit(ir);
  assert.equal(v.errors.length, 0); assert.equal(v.stats.nmos, 4); assert.equal(v.stats.pmos, 2);
  const r = renderSchematic(ir);
  assert.equal((r.svg.match(/class="sym"/g) ?? []).length, 6);
  assert.deepEqual(Object.entries(r.report.nets).filter(([, n]) => !n.routed), []);
  assert.match(r.svg, /TEST FIXTURE/);
});
test('floating pins are rejected, not drawn', () => {
  const ir = load('circuit_6t'); delete ir.components[0].pins.g;
  const res = renderCircuitSafe(ir);
  assert.equal(res.ok, false);
});
test('unknown net reference is an error', () => {
  const ir = load('circuit_6t'); ir.components[0].pins.d = 'nope';
  assert.ok(validateCircuit(ir).errors.some((e) => e.code === 'bad_net_ref'));
});
test('auto layout works without placement hints', () => {
  const r = renderSchematic(load('circuit_amp')); assert.equal(r.report.layout, 'auto');
  assert.deepEqual(r.report.unconnectedPins, []);
});
test('methodology renders groups, labelled edges and feedback', () => {
  const ir = load('methodology_puf'); assert.equal(validateMethodology(ir).errors.length, 0);
  const r = renderMethodology(ir);
  assert.equal((r.svg.match(/class="edge/g) ?? []).length, ir.edges.length);
  assert.match(r.svg, /class="edge fb"/); assert.match(r.svg, /OPERATION/);
});
test('thin methodology is refused (never a row of boxes)', () => {
  assert.equal(renderMethodologySafe({ version: 1, nodes: [{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }], edges: [{ from: 'a', to: 'b' }] }).ok, false);
});
test('structure: array dimensions come from the IR', () => {
  const ir = load('structure_array'); assert.equal(validateStructure(ir).errors.length, 0);
  const s = buildStructureScene(ir);
  assert.equal(s.boxes.filter((b) => b.kind === 'cell').length, 256); assert.equal(s.detail?.boxes.length, 7);
  ir.root.children[0].count = { rows: 4, cols: 8 };
  assert.equal(buildStructureScene(ir).boxes.filter((b) => b.kind === 'cell').length, 32);
});
test('structure: array without a cell is invalid', () => {
  const ir = load('structure_array'); ir.root.children[0].children = [];
  assert.equal(buildStructureSafe(ir).ok, false);
});
